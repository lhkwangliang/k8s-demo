package com.wl.session.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringSessionDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringSessionDemoApplication.class, args);
	}

}
