//package com.wl.session.demo;
//
//import redis.clients.jedis.JedisPool;
//import redis.clients.jedis.JedisPoolConfig;
//
//public class Test {
//
//	public static void main(String[] args) {
//		redis.clients.jedis.Jedis jedis= null;
//		try {
//			JedisPoolConfig jedisPoolConfig = new JedisPoolConfig();
//			JedisPool jedisPool = new JedisPool(jedisPoolConfig, "192.168.17.128", 7010, 2000, null);
//			jedis = jedisPool.getResource();
//			String set = jedis.set("abc", "abc");
//			System.out.println(jedis.get("abc"));
//		} catch (Exception e) {
//			e.printStackTrace();
//		} finally {
//			if (jedis != null) {
//				jedis.close();
//			}
//		}
//	}
//}
